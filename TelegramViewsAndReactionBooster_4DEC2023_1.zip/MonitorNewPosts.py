import configparser
from telethon import TelegramClient, events
from telethon.tl.types import User, Channel, Chat, ChatEmpty
from rich import print
import time
from threading import Thread,Event
from NewpostThreads import startSendingViews,sendReactionThreadWrapper,async_startSendingViews
from CustomFunctions import selectionState,sendReactions
from os import system, name
import shutil
import threading
from GlobalVariables import Gvar
config=configparser.ConfigParser()
config.read("config.ini")

stop_event = Event()

system('cls' if name=='nt' else 'clear')
terminal_width = shutil.get_terminal_size().columns
print("""
        Created By : 'Roshan Yadav' https://t.me/roshanyadavse
              
         Powered By 'BridgeSkillz' https://bridgeskillz.com/
              
                      Phone no : 8476868560
        \n\n""".center(100))

api_id = config["MonitorNewPost"]["api_id"]
api_hash = config["MonitorNewPost"]["api_hash"]

minimumviews = int(config["Global"]["minimumviews"])

MonitoringList = config["MonitorNewPost"]["monitorchannel"]
MonitoringList = [int(id.strip()) for id in MonitoringList.split(",") if id]


client = TelegramClient('anon', api_id, api_hash)
groupmsg=[] 
@client.on(events.NewMessage)
async def my_event_handler(event):
    try:
        chat = await event.get_chat()
        if not isinstance(chat, Channel):
            return
        
        sender = await event.get_sender()
        chat_id = event.chat_id
        sender_id = event.sender_id
        if chat_id in MonitoringList:
            if event.message.grouped_id is None or event.message.grouped_id not in groupmsg:
                groupmsg.append(event.message.grouped_id)
                print(Gvar.viewsmapping,chat_id,f"{chat_id}" in Gvar.viewsmapping)
                if f"{chat_id}" in Gvar.viewsmapping:
                    lminimumviews=int(Gvar.viewsmapping[f"{chat_id}"])
                    print("[+] Have Limit",lminimumviews)
                    task1 = async_startSendingViews(f"https://t.me/{chat.username}/{event.message.id}",lminimumviews)
                else:
                    print("[+] No Limit",minimumviews)
                    task1 = async_startSendingViews(f"https://t.me/{chat.username}/{event.message.id}",minimumviews)

                await task1
                if selectionState():
                    chanel_id=chat.username
                    post_id=event.message.id
                    Gvar.REACTIONCOUNT[f"{chanel_id}_{post_id}"]="Started"
                    await sendReactions(chanel_id,post_id)

    except Exception as e:
        print(f"[+] my_event_handler Error : {e}")

def parseTime(initial,final):
    time_spent_seconds = final - initial
    hours = int(time_spent_seconds // 3600)
    remaining_seconds = time_spent_seconds % 3600
    minutes = int(remaining_seconds // 60)
    seconds = int(remaining_seconds % 60)
    return f"{hours}:{minutes}:{seconds}"

def terminal():
    start_time = time.time()
    while not stop_event.is_set():
        ipusageformated={key:len(Gvar.ipUsageTrack[key]) for key in Gvar.ipUsageTrack}
        end_time = time.time()
        print(f"[+] Uptime : {parseTime(start_time,end_time)}",end=" ")
        print(f"[+] ThreadCount : {threading.active_count()}",end=" ")
        print(f"[+] Monitoring : {MonitoringList}\n")
        print(f"[+] BlacklistedPosts : {Gvar.BLACKLIST}\n")
        print(f"[+] Errors : {Gvar.ERRORLOG}")
        print(f"[+] Processed : {Gvar.ProcessedPost}")
        print(Gvar.NewPosts)
        if Gvar.proxytype=="d":
            print(f"[+] Total Ip : {len(Gvar.DatacenteredIps)}")
            print(f"[+] Ip Uage :{ipusageformated}")

        print("\n\n")
        time.sleep(2)
        system('cls' if name=='nt' else 'clear')

client.start()
Thread(target=terminal).start()
client.run_until_disconnected()
stop_event.set()